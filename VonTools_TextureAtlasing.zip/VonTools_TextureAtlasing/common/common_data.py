import bpy # type: ignore




# ----------------------
# Basic Property Group
# ----------------------
class common_data(bpy.types.PropertyGroup):
    my_float: bpy.props.FloatProperty(name="My Float") # type: ignore

# ----------------------
# Registration
# ----------------------
classes = [
    common_data
]

def register():
    from bpy.utils import register_class # type: ignore
    for cls in classes:
        register_class(cls)
    bpy.types.Scene.common_data = bpy.props.PointerProperty(type=common_data)

def unregister():
    del bpy.types.Scene.common_data
    from bpy.utils import unregister_class # type: ignore
    for cls in reversed(classes):
        unregister_class(cls)